import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db/connect";
import ParameterField from "@/models/ParameterField";

export async function GET() {
  await connectDB();

  const data = await ParameterField.find().populate("parameterId");

  return NextResponse.json({
    success: true,
    data,
  });
}
export async function POST(req: Request) {
  await connectDB();

  const body = await req.json();

  const field = await ParameterField.create(body);

  return NextResponse.json({
    success: true,
    data: field,
  });
}
